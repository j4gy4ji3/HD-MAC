library(glmnet)
library(data.table)
library(shinyWidgets)
library(shinyjs)
library(shinyBS)
library(shinydashboard)
library(selectiveInference)
# library(finalfit)
# library(pROC)
# library(ggplot2)
# library(survminer)
# library(devtools)
# library(rsconnect)
# data.table: https://www.ptt.cc/bbs/R_Language/M.1437467101.A.E6D.html

source("c_index.R", encoding = "BIG5")
source("lr_gene_penalty_cv_function_version2.R")
source("cox_gene_penalty_cv_function_version2.R")
source("toy_example.R")
# source("CopyOf1_1_lr_clin_cov.R", encoding = "BIG5")
# source("CopyOf2_1_cox.R", encoding = "BIG5")

# Define server logic to read selected file ----
options(shiny.maxRequestSize=100*1024^2) 


server <- function(input, output, session) {
  
  #### 1. Import Data ####
  #### 1-a. Load Data                                  ####
  #### Load data : User Own Data
  inData1 <- reactive({
    inFile <- input$file1
    if(is.null(inFile))return(NULL)
    data.frame(fread(inFile$datapath, 
                     header = input$header, 
                     stringsAsFactors = input$stringsAsFactors, 
                     sep = ","))
    })
  
  inData <- reactive({
    switch(input$select,
           "toy" = Blad_SUB_8clinical_4937mut_8024mRNA,
           "uploaded" = inData1())
  })
  
  #### 1-b. row.col.sentence                           ####
  output$row.col.sentence = renderText({
    if(is.null(inData())){
      return(NULL)
    }else{
      paste(c("There are ", nrow(inData()), "patients and ", ncol(inData()), "variables.")) }
  })
  
  #### 1-c. DataTable                                  ####
  # datatable tutorial : https://shiny.rstudio.com/gallery/datatables-options.html
  output$contents <- renderDataTable(
    expr    = inData()[,c(input$ncol1:input$ncol2)],
    options = list(lengthMenu = list(c(5, 15, -1), c('5', '15', 'All')), pageLength = 10)
  )
  
  #################################################
  # #### 2. Summary Table ####
  # #### 2-a. Define outcome(response)                   ####
  # ### Define dependent variable if survival object
  # observeEvent(inData(), {
  #   updateSelectInput(session, "response", choices = colnames(inData())[1:10])
  # })
  # observeEvent(inData(), {
  #   updateSelectInput(session, "status", choices = colnames(inData())[1:10])
  # })
  # dependent <- reactive({
  #   if(!input$survival){
  #     input$response
  #   }else if(input$survival){
  #     paste0("Surv(", input$response, ",", input$status, ")")
  #   }
  # })
  # 
  # #### 2-b. Define clinical variables                  ####
  # observeEvent(inData(), {
  #   updateSelectInput(session, "clinical_con_selector", choices = colnames(inData())[1:10])
  # })
  # pred.con.col <- reactive({
  # 
  #   # inPred <- which( colnames(inData()) %in%  input$clinical_con_selector )
  #   inPred <- input$clinical_con_selector
  #   if (is.null(inPred)) return(NULL)
  # 
  #   inPred
  # 
  # })
  # 
  # #### 2-c. Fit                                        ####
  # fit = reactive({
  #   finalfit::finalfit(as.data.frame(inData()),
  #                       dependent = dependent(),
  #                       explanatory = pred.con.col(),
  #                       confint_type = 0.95)
  #   # if (is.null(sum.list)) return("Please input data or covariates.")
  #   # sum.list
  #   })
  # fit_column_n = reactive(dim(fit())[2])
  # output$results <- renderDataTable(
  #   expr = fit(),
  #   options = list(dom = 't',
  #                  scrollX    = TRUE,
  #                  paging     = FALSE,
  #                  fixedColumns = list(leftColumns = 1, rightColumns = 0),
  #                  searching  = FALSE,
  #                  columnDefs = list(list(className = 'dt-right', targets = 2:fit_column_n()-1)))
  # )
  # 
  # 
  # #### 2-d. KM-surv curve                              ####
  # # output$kmsurv_button <- renderUI({
  # #   actionButton('km.surv', "Run KM survival curve!")
  # # })
  # # 
  # # km.surv.plot <- eventReactive(input$km.surv,{
  # #   if (is.null(  input$cox_selected_factor_predictors  )) {
  # #     survkm = survfit(Surv( inData()[,cox.time.col()], inData()[,cox.event.col()] ) ~ 1)
  # #     ggsurvplot(survkm,
  # #                data = inData(),
  # #                palette = c("#2E9FDF"),
  # #                risk.table = T,
  # #                ggtheme = theme_bw())}
  # #   else{
  # #     survkm = survfit(Surv(inData()[,cox.time.col()], inData()[,cox.event.col()]) ~ inData()[,cox.predictors.cat.col()])
  # #     ggsurvplot(survkm,
  # #                data = inData(),
  # #                risk.table = T,
  # #                ggtheme = theme_bw())
  # #   }  
  # #   })
  # # 
  # # output$km.surv.plot.result = renderPlot({
  # #   km.surv.plot()
  # # })
  #################################################
  #### 3. Binary Response (Logistic regression) ####

  #### 3-a. Model                                      ####
  output$m1 <- renderUI({
    withMathJax('$$P(Y_{i}=1|X_{i})=\\frac{e^{\\beta^{T}X_{i}}}{1+e^{\\beta^{T}X_{i}}} \\Leftrightarrow 
                   log\\left (\\frac{P(Y_{i}=1|X_{i})}{P(Y_{i}=0|X_{i})}\\right ) = \\beta^{T}X_{i}$$')
  })
  
  #### 3-b. Response                                   ####
  output$response_selector <- renderUI({
    if(is.null(inData())){
      return(NULL)
    }else{
      pickerInput(
        inputId  = "selected_response", "Choose the response variable",
        choices  = colnames(inData())[1:15],
        selected = NULL,
        multiple = F, 
        options  = list('actions-box'=TRUE, title="Click here", 'deselect-all-text'="None", 'select-all-text'="All"),
        width = '80%'
      )
    }
  })
  
  #### 3-c. Clinical covaristes: X conti.              ####
  output$predictors_continuous_selector <- renderUI({
    if(length(input$selected_response) == 0){
      return(NULL)
    }else{
      pickerInput(
        inputId  = "selected_continuous_predictors", "Define continuous clinical covariates (optional)", 
        choices  = (colnames(inData())[!colnames(inData()) %in% input$selected_response])[1:15],
        selected = NULL,
        multiple = T, 
        options  = list('actions-box' = TRUE, title = "Click here", 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width    = '80%'
      )
    }
  })
  
  output$predictors_factor_selector <- renderUI({
    if(length(input$selected_response) == 0){
      return(NULL)
    }else{
      pickerInput(
        inputId  = "selected_factor_predictors", "Define categorical clinical covariates (optional)", 
        choices  = (colnames(inData())[!colnames(inData()) %in% c(input$selected_response,input$selected_continuous_predictors)])[1:15],
        selected = NULL,
        multiple = T, 
        options  = list('actions-box' = TRUE, title = "Click here", 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width    = '80%'
      )
    }
  })
  
  #### 3-d. Select clinical covaristes for mixed model ####
  output$covaristes_model <- renderUI({
    if(length(input$selected_response) == 0){
      return(NULL)
    }
    else{
      pickerInput(
        inputId  = "selected_covariates_model", "Choose clinical covariates to fit model (optional):", 
        choices  = (colnames(inData())[colnames(inData()) %in% c(input$selected_factor_predictors,input$selected_continuous_predictors)]),
        selected = NULL,
        multiple = T, 
        options  = list('actions-box' = TRUE, title = "Click here", 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width    = '100%'
      )
    }
  })
  
  
  #### 3-e. Define response colunm                     ####
  # reaction of 3-b. Response
  response.col <- reactive({
    inResp <- input$selected_response
    if (is.null(inResp))
      return(NULL)
    inResp
  })
  
  #### 3-f. Define X contiuous columns                 ####
  predictors.col <- reactive({
    inPred <- which( colnames(inData()) %in%  input$selected_continuous_predictors )
    if (is.null(inPred)) return(NULL)
    inPred
  })
  # Define X categorical columns
  predictors.cat.col <- reactive({
    inPred <- which( colnames(inData()) %in%  input$selected_factor_predictors )
    if (is.null(inPred)) return(NULL)
    inPred
  })
  
  # Define X categorical columns
  covariates.lr.model <- reactive({
    inPred <- which( colnames(inData()) %in% input$selected_covariates_model )
    if (is.null(inPred)) return(NULL)
    inPred
  })
  
  
  #### 3-g. Run the result                             ####
  output$lr.gene_button <- renderUI({
    if(is.null(inData()))
      return(NULL)
    # icon tutorial: https://fontawesome.com/icons?d=gallery&q=play
    actionButton(inputId = 'lr.gene', 
                 label = "Run!",
                 icon("play"),
                 style = 'color: #fff; background-color: #337ab7; border-color: #2e6da4padding:4px; font-size:250%')
  })
  lr.gene.cv <- eventReactive(input$lr.gene, {
    if(is.na(input$gene.col)|is.na(input$gene.col.end)){
      gene.gene.col = NULL
      }
    else{
      gene.gene.col = input$gene.col:input$gene.col.end
      }
    
    lr.list = lr.gene.penalty.cv.result(user.data = inData(), 
                                        response.col  = response.col(), 
                                        gene.type     = list(gene.var = colnames(inData())[gene.gene.col]),
                                        padj.method   = if(input$fdr){"fdr"}else{"none"}, 
                                        fdr.threshold = input$fdr_threshold,
                                        penalty.alpha = input$penalty_select , 
                                        nfold         = input$num.cv.fold, 
                                        force.add.cov = covariates.lr.model())
    if (is.null(inData())) return(NULL)
    lr.list
  })
  
  #### 3-h. Sen, Spe, Accuracy, AUC, Gene List         ####
  output$lr.gene.cv.result.sen      = renderPrint({ lr.gene.cv()$sen })
  output$lr.gene.cv.result.spe      = renderPrint({ lr.gene.cv()$spe })
  output$lr.gene.cv.result.acy      = renderPrint({ lr.gene.cv()$accuracy })
  output$lr.gene.cv.result.auc      = renderPrint({ lr.gene.cv()$mean.auc })
  output$lr.gene.cv.result.lamd     = renderPrint({ lr.gene.cv()$ld })
  output$lr.gene.cv.result.coefandp = renderPrint({ lr.gene.cv()$coef.and.p })
  
  
  #################################################
  #### 4. Survival Response (Cox PH regression)
  #### 4-a. Model                                      ####
  output$m2 <- renderUI({
    withMathJax('$$h(t)=h_{0}(t)\\times e^{\\beta^{T}X_{i}}$$')
  })

  #### 4-b. cox_event: Status covariate                ####
  output$cox_event <- renderUI({
    if(is.null(inData())){
      return(NULL)
    }else{
      pickerInput(
        inputId = "cox_selected_event", "Choose the event variable",
        choices = colnames(inData())[1:15],
        selected = NULL,
        multiple = F, options = list('actions-box' = TRUE, title = "Click here"
                                     , 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width = '80%'
      )
    }
  })
  
  #### 4-c. cox_time: Time covariate                   ####
  output$cox_time <- renderUI({
    if(is.null(inData())){
      return(NULL)
    }else{
      pickerInput(
        inputId = "cox_selected_time", "Choose the time variable",
        choices = colnames(inData())[1:15],
        selected = NULL,
        multiple = F, options = list('actions-box' = TRUE, title = "Click here"
                                     , 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width = '80%'
      )
    }
  })
  
  #### 4-d. Clinical covaristes: X conti.              ####
  output$cox_predictors_selector <- renderUI({
    if(length(input$cox_selected_event) == 0|length(input$cox_selected_time) == 0){
      return(NULL)
    }else{
      pickerInput(
        inputId = "cox_selected_predictors", "Define continuous clinical covariates (optional)", 
        choices = (colnames(inData())[!colnames(inData()) %in% c(input$cox_selected_event, input$cox_selected_time) ])[1:10],
        selected = NULL,
        multiple = T, options = list('actions-box' = TRUE, title = "Click here"
                                     , 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width = '80%'
      )
    }
  })
  
  #### 4-e. Clinical covaristes: X categorical         ####
  output$cox_predictors_factor_selector <- renderUI({
    if(length(input$cox_selected_event) == 0|length(input$cox_selected_time) == 0){
      return(NULL)
    }else{
      pickerInput(
        inputId = "cox_selected_factor_predictors", "Define categorical clinical covariates (optional)", 
        choices = (colnames(inData())[!colnames(inData()) %in% c(input$cox_selected_event,input$cox_selected_time,input$cox_selected_predictors)])[1:10],
        selected = NULL,
        multiple = T, options = list('actions-box' = TRUE, title = "Click here"
                                     , 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width = '80%'
      )
    }
  })
  
  #### 4-f. Select clinical covaristes for mixed model ####
  output$cox_covaristes_model <- renderUI({
    if(length(input$cox_selected_event) == 0|length(input$cox_selected_time) == 0){
      return(NULL)
    }else{
      pickerInput(
        inputId = "cox_selected_covariates_model", "Choose the covariates to fit in model (optional):", 
        choices = (colnames(inData())[colnames(inData()) %in% c(input$cox_selected_factor_predictors,input$cox_selected_predictors)]),
        selected = NULL,
        multiple = T, options = list('actions-box' = TRUE, title = "Click here"
                                     , 'deselect-all-text' = "None", 'select-all-text' = "All"),
        width = '100%'
      )
    }
  })
  
  #### 4-g. Define response(time,event) col            ####
  cox.time.col <- reactive({
    inResp <- which( colnames(inData()) %in% input$cox_selected_time  )
    if (is.null(inResp))return(NULL)
    inResp
  })
  cox.event.col <- reactive({
    inResp <- which( colnames(inData()) %in% input$cox_selected_event  )
    if (is.null(inResp))return(NULL)
    inResp
  })
  
  #### 4-h. Define X conti col                         ####
  cox.predictors.col <- reactive({
    
    inPred <- which( colnames(inData()) %in%  input$cox_selected_predictors )
    
    if (is.null(inPred)) return(NULL)
    
    inPred
    
  })
  cox.predictors.cat.col <- reactive({
    
    inPred <- which( colnames(inData()) %in%  input$cox_selected_factor_predictors )
    
    if (is.null(inPred)) return(NULL)
    
    inPred
    
  })
  
  #### 4-i. cox variable in mixed model                ####
  cox.covariates <- reactive({
    
    inPred <- which( colnames(inData()) %in%  input$cox_selected_covariates_model )
    
    if (is.null(inPred)) return(NULL)
    
    inPred
    
  })
  
  #### 4-j. Print columns number                       ####
  # Mutation col and Expression col
  output$gene.col <- renderText({ paste(c("Genetic covariates columns from",input$gene.col,"to",input$gene.col.end))  })
  
  #### 4-k. Run the result                             ####
  output$cox.gene_button <- renderUI({
    if(is.null(inData()))
      return(NULL)
    actionButton('cox.gene', 
                 "Run!",
                 icon("play"),
                 style = 'color: #fff; background-color: #337ab7; border-color: #2e6da4padding:4px; font-size:250%')
    
  })
  cox.gene.cv <- eventReactive(input$cox.gene, {
    if(is.na(input$gene.col_cox)|is.na(input$gene.col.end_cox)){ gene.gene.col.cox =  NULL }else{ 
      gene.gene.col.cox = input$gene.col_cox:input$gene.col.end_cox }
    
    cox.list = cox.gene.penalty.cv.result(user.data = inData(),
                                          time.col  = cox.time.col(), 
                                          event.col = cox.event.col(), 
                                          gene.type =  list(gene.var = colnames(inData())[gene.gene.col.cox]),
                                          padj.method   = if(input$fdr_cox){"fdr"}else{"none"}, 
                                          fdr.threshold = input$fdr_threshold_cox,
                                          penalty.alpha = input$penalty_select_cox , 
                                          nfold = input$num.cv.fold_cox, 
                                          force.add.cov = if(length(cox.covariates()) == 0){NULL}else{
                                            cox.covariates()
                                          }
    )
    if (is.null(inData())) return(NULL)
    cox.list
  })
  
  #### 4-l. c-index, Gene List                         ####
  output$cox.gene.cv.result.cindex = renderPrint({
    cox.gene.cv()$c_index
  })
  output$cox.gene.cv.result.genelist = renderPrint({
    cox.gene.cv()$selected.gene
  })
  
  output$cox.gene.cv.result.coefandp = renderPrint({ cox.gene.cv()$coef.and.p})
  
  
  #################################################
  #### 5. Tutorial (screen shot)
  #### 5. Tutorial - text                              ####
  output$text5_1 <- renderText({ paste("The high-dimensional analysis of cancer-associated genetic alterations, HDCAGP, was developed to analyze high-dimensional genetic covariates, with the choice of including clinical covariates, with several regression models suitable for high-dimensional analysis and to identify important genetic alterations which could be used to construct a fitted multivariate regression model while its prediction power could be estimated by cross validation. HDCAGP also allows choice of a penalty type for the corresponding penalized regression model for high-dimensional data and a first-step screening to screen out unrelated variables if the multiple-testing problem is of concern via control of the false discovery rate (FDR). Below is a tutorial on how to use HDCAGP with respect of both survival data and binary outcome. The platform is available at http://ripsung26.shinyapps.io/rshiny.") })
  output$text5_2 <- renderText({ paste("Data Upload/Toy Example") })
  output$text5_3 <- renderText({ paste("To begin the analysis of your data, go to the website listed above and click the tab “Upload Data”. On the left of the page, you may choose whether to upload your own data or use the toy example we provided on the site. The data you upload or from our toy example are shown on the right. You may also choose which columns are shown on the front page.") })
  output$text5_4 <- renderText({ paste("The size limit to the data you upload is 50 MB. It may take a few moments for your data to upload dependent on the size.") })
  output$text5_5 <- renderText({ paste("Once the data are uploaded, you may begin your analysis. For survival data, click the tab “Survival Regress: CoxPH Model”. For binary outcomes, click the tab “Binary Regression: Logistic Regression Model”.") })
  output$text5_5 <- renderText({ paste("Survival Analysis") })
  output$text5_7 <- renderText({ paste("The data used here to illustrate how to run survival analysis on HDCAGP contain the information of 8,310 mutated genes from 316 patients with serous type, high grade ovarian cancer from TCGA. The aim is to relate gene mutations to the patients’ overall survival.") })
  output$text5_8 <- renderText({ paste("1. Choose the tab “Survival Response: CoxPH Model” and locate all the variables needed for the analysis in the data uploaded. Inclusion of clinical variables is optional. Then choose the Cox regression method desired. Three are available: ridge, Lasso and adaptive Lasso.") })
  output$text5_9 <- renderText({ paste("2. Print the gene list. [Optional:] Choose whether the initial screening to control the FDR is desired. If chosen (the box before “Use FDR for screening” is checked as shown below), the p-value threshold is set at 0.05. The number of cross-validation (CV) folds for testing the prediction power (C-index in the case of survival analysis) is set at 1 as the default for printing out gene lists. It is possible to change the CV fold for statistical tests, which is illustrated in the next step.") })
  output$text5_10<- renderText({ paste("Hit “Run” and the gene list with each gene’s coefficient and p value will be printed on the page.") })
  output$text5_11<- renderText({ paste(" 3. (Optional) To test the prediction power of the results, set the CV folds at 5 and hit RUN.") })
  output$text5_12<- renderText({ paste("The concordance index, C-index, will be calculated to show the prediction power.") })
  output$text5_13<- renderText({ paste("Binary Outcome") })
  output$text5_14<- renderText({ paste("The data used here to illustrate how to run logistic regression in response to a binary outcome on HDCAGP contain the information of 18,335 entries of mRNA expression of 189 patients with bladder cancer from TCGA. The aim is to relate abnormal mRNA expression to the patients’ cancer subtype, invasive vs. non-invasive.") })
  output$text5_15<- renderText({ paste("1. Choose the tab “Binary Response: Logistic Regression Model” and locate all the variables needed for the analysis in the data uploaded. Inclusion of clinical variables is optional. Then choose the logistic regression method desired. Three are available: ridge, Lasso and adaptive Lasso.") })
  output$text5_16<- renderText({ paste("2. Print the gene list. [Optional:] Choose whether the initial screening to control the FDR is desired. If chosen (the box before “Use FDR for screening” is checked as shown below), the p-value threshold is set at 0.05. The number of cross-validation (CV) folds for testing the prediction power (sensitivity, specificity, accuracy and area under curve (AUC) in the case of logistic regression) is set at 1 as the default for printing out gene lists. It is possible to change the CV fold for statistical tests, which is illustrated in the next step.") })
  output$text5_17<- renderText({ paste("Hit “Run” and the gene list with each gene’s coefficient and p value will be printed on the page.") })
  output$text5_18<- renderText({ paste("3. (Optional) To test the prediction power of the results, set the CV folds at 5 and hit RUN. ") })
  output$text5_19<- renderText({ paste("The sensitivity, specificity, accuracy, and AUC will be calculated to show the prediction power.") })
  
  #### 5. Tutorial - image                             ####
  output$image1 <- renderImage({ list(
    src = "picone.png",
    contentType = "image/png"
    ) }, deleteFile=FALSE)
  output$image2 <- renderImage({ list(
    src = "2.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image3 <- renderImage({ list(
    src = "3.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image4 <- renderImage({ list(
    src = "4.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image5 <- renderImage({ list(
    src = "5.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image6 <- renderImage({ list(
    src = "6.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image7 <- renderImage({ list(
    src = "7.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image8 <- renderImage({ list(
    src = "8.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image9 <- renderImage({ list(
    src = "9.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image10 <- renderImage({ list(
    src = "10.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image11 <- renderImage({ list(
    src = "11.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image12 <- renderImage({ list(
    src = "12.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)
  output$image13 <- renderImage({ list(
    src = "13.png",
    contentType = "image/png"
  ) }, deleteFile=FALSE)

  }