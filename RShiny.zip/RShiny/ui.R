# .libPaths("D:/Rlibrarys")
# library(rsconnect)
# library(devtools)
# deployApp(account = "ripsung26")
library(shiny)
library(glmnet)
library(data.table)
library(shinydashboard)
library(shinyWidgets)
library(shinyjs)
library(shinyBS)
library(selectiveInference)
# library(finalfit)
# library(pROC)
# library(survminer)
# high-dimensional analysis of molecular alterations in cancer

shinyUI(
  navbarPage("HD-MAC",
             #### table1: Upload Data         ####
             tabPanel("Upload data",
                      
                      # Sidebar layout with input and output definitions 
                      sidebarLayout(
                        # Sidebar panel for inputs
                        sidebarPanel(
                          
                        #### Input: Select toyexample or upload your own data ####
                        selectInput(inputId = "select",
                                    label = "Select toy example or upload your own data",
                                    choices = c(Toy_example = "toy", Upload_data = "uploaded"),
                                    selected = "toy"),
                          
                        #### Panel of toy example : ####
                        conditionalPanel(condition = "input.select == 'toy'",
                                           
                                         # show colunms
                                         numericInput("ncol1", "Show columns of data from ", 1 , min = 1, max = 27380),
                                         numericInput("ncol2", "to", 10, min = 1, max = 27380)
                                         ),
                          
                        #### Panel of uploaded data : ####
                        conditionalPanel(condition = "input.select == 'uploaded'",
                                         # Input: Select a file
                                         fileInput("file1", "Upload your own csv file",
                                                   multiple = FALSE,
                                                   accept = c("text/csv",
                                                              "text/comma-separated-values,text/plain",
                                                              ".csv")),
                                           
                                         # annotation:
                                         helpText("1. Data size limit is 50 MB."),
                                         helpText("2. Your data should be consisted of response variable, genetic covariates (necessary) and clinical ones (optional)."),
                                         helpText("3. The clinical covariates (including response) should precede the genetic."),
                                           
                                         # Input: Checkbox if file has header
                                         checkboxInput("header", label = "Header", value = TRUE),
                                         checkboxInput("stringsAsFactors", label = "stringsAsFactors", value = TRUE),
                                           
                                         # Horizontal line
                                         tags$hr(),
                                           
                                         # show colunms
                                         numericInput("ncol1", "Show columns of data from ", 1 , min = 1, max = 27380),
                                         numericInput("ncol2", "to", 10, min = 1, max = 27380)
                                         )
                          ),
                        
                        #### Main panel for displaying outputs ####
                        mainPanel(
                          # server: 67 rows
                          textOutput("row.col.sentence"),
                          
                          # Output: Data file
                          dataTableOutput('contents')
                          # tableOutput("contents")
                        )
                      )
             ), # tabPanel: "Upload Data" -- End
             
             
             #### table : Summary Statistics  ####
             # tabPanel("Summary Statistic",
             #          h3("Model parameters"),
             #          ## check response:
             #          checkboxInput("survival",
             #                        label = "Survival object",
             #                        value = FALSE),
             #          selectInput(inputId = "response", label = "Response:", character(0)),
             #          conditionalPanel(condition = 'input.survival == true',
             #                           selectInput("status", "Status:", character(0))),
             #          # uiOutput("outcome"),
             #          # conditionalPanel(condition = 'input.survival == true',
             #          #                  uiOutput("status")),
             # 
             #          ## select clinical variables
             #          h3("Select clinical covariates"),
             #          selectInput(inputId = "clinical_con_selector", label = "Clinical variable:", character(0), multiple = T),
             #          # uiOutput("sum_clinical_con_selector"),
             #          # uiOutput("predictors_factor_selector"),
             #          hr(),
             # 
             #          ## execution button
             #          h3("Summary Statistic"),
             #          dataTableOutput("results"),
             #          # DT::dataTableOutput("results"),
             #          hr()
             # 
             #          # h4("Kaplan-Meier Survival Curve"),
             #          # uiOutput("kmsurv_button"),
             #          # plotOutput("km.surv.plot.result"),
             #          # hr(),
             #          #
             #          # h4("Univariate Cox Model P-value"),
             #          # verbatimTextOutput("cox.clinical.p") # p.value for each covariate
             # ),
             # 
             # 

             #### table3: Logistic Regression ####
             tabPanel("Binary Response : Logistic Regression Model",
                      #### model                                   ####
                      h3("Logistic Regression Model:"),
                      uiOutput('m1'),
                      hr(),
                      
                      #### Input: Select response                  ####
                      h3("Response"),
                      uiOutput("response_selector"),
                      hr(),
                      
                      #### Input: Covariates(genetic and clinical) ####
                      h3("Covariates"),
                      fluidRow(
                        column(4,
                               # genetic covariate column
                               numericInput('gene.col', 'Genetic covariates columns from', NULL, min = 1),
                               numericInput('gene.col.end', 'to', NULL, min = 1),
                               helpText("PS:Binary covariates should be represented by 0 and 1.")),
                        
                        column(4,
                               uiOutput("predictors_continuous_selector"),
                               uiOutput("predictors_factor_selector"),
                               uiOutput("covaristes_model"))
                      ),
                      hr(),
                      
                      #### Input: Regression penalty               ####
                      h3("Choose regression penalty for the model"),
                      selectInput('penalty_select', 'Regression penalty', c("Ridge" = 0,"Lasso" = 1,"Adaptive Lasso" = 2), selected = 1),
                      hr(),
                      
                      #### Input: Screening                        ####
                      h3("Screening (optional)"),
                      checkboxInput("fdr", "Use FDR for screening", FALSE),
                      numericInput('fdr_threshold', 'p-value threshold', 1, min = 0, max = 1, step = 0.01),
                      hr(),
                      
                      #### Input: number of cross-validation folds ####
                      h3("Cross-Validation for prediction power (optional)"),
                      numericInput('num.cv.fold', 'Number of CV folds', 1, min = 1, max = 10, step = 1),
                      hr(),
                      
                      #### Run Button: Method                      ####
                      fluidRow(
                        column(4, uiOutput('lr.gene_button')),
                        column(4, textOutput("gene.col"))
                      ),
                      hr(),
                      
                      #### Output: Final Result                    ####
                      h3("Final Result"),
                      hr(),
                      
                      tabsetPanel(
                        tabPanel("Gene List, estimated coefficients and p-values", 
                                 # h4("Gene List"),
                                 # verbatimTextOutput("lr.gene.cv.result.genelist"),
                                 
                                 # h4("Gene list, estimated coefficients and p-values"),
                                 # verbatimTextOutput("lr.gene.cv.result.lamd")
                                 
                                 h4("Gene list, estimated coefficients and p-values"),
                                 verbatimTextOutput("lr.gene.cv.result.coefandp")
                                 ),
                        
                        tabPanel("Prediction Power", 
                                 h4("Sensitivity"),
                                 # helpText("Sensitivity (also called the true positive rate or probability of detection) measures the proportion of actual positives that are correctly identified."),
                                 verbatimTextOutput("lr.gene.cv.result.sen"),
                                 
                                 h4("Specificity"),
                                 # helpText("Specificity (also called the true negative rate) measures the proportion of actual negatives that are correctly identified."),
                                 verbatimTextOutput("lr.gene.cv.result.spe"),
                                 
                                 h4("Accuracy"),
                                 # helpText("Overall accuracy."),
                                 verbatimTextOutput("lr.gene.cv.result.acy"),
                                 
                                 h4("AUC (%)"),
                                 # helpText("Area Under the ROC Curve. Evaluate the performance of regression model."),
                                 verbatimTextOutput("lr.gene.cv.result.auc")
                                 )
                      )

             ),
             
             
             
             
             
             
             
             
             
             
             #### table4: coxph regression    ####
             tabPanel("Survival Response : CoxPH Model",
                      #### model                                   ####
                      h3("Cox PH Model:"),
                      uiOutput('m2'),
                      hr(),
                      
                      #### Input: Select number of rows to display ####
                      h3("Response"),
                      uiOutput("cox_time"),
                      uiOutput("cox_event"),
                      hr(),
                      
                      #### Input: Covariates(genetic and clinical) ####
                      h3("Covariates"),
                      fluidRow(
                        column(4,
                               # genetic covariate column
                               numericInput('gene.col_cox', 'Genetic covariates columns from',  NULL, min = 1),
                               numericInput('gene.col.end_cox', 'to',  NULL, min = 1),
                               helpText("PS:Binary covariates should be represented by 0 and 1.")),
                        
                        column(4,
                               uiOutput("cox_predictors_selector"),
                               uiOutput("cox_predictors_factor_selector"),
                               uiOutput("cox_covaristes_model"))
                      ),
                      hr(),
                      
                      #### Input: Regression penalty               ####
                      h3("Choose regression penalty for the model"),
                      selectInput('penalty_select_cox', 
                                  'Regression penalty', 
                                  c("Ridge" = 0,"Lasso" = 1,"Adaptive Lasso" = 2),
                                  selected = 1),
                      hr(),
                      
                      #### Input: Screening                        ####
                      h3("Screening (optional)"),
                      checkboxInput("fdr_cox", 
                                    "Use FDR for screening", 
                                    FALSE),
                      numericInput('fdr_threshold_cox', 
                                   'p-value threshold', 1, min = 0, max = 1,
                                   step = 0.01),
                      hr(),
                      
                      #### Input: number of cross-validation folds ####
                      h3("Cross-Validation for prediction power (optional)"),
                      numericInput('num.cv.fold_cox', 
                                   'Number of cv folds', 1, min = 1, max = 10,
                                   step = 1),
                      hr(),
                      
                      #### Run Button: Method                      ####
                      fluidRow(
                        column(4, uiOutput('cox.gene_button')),
                        column(4, textOutput("mut.col_cox")),
                        column(4,  textOutput("exp.col_cox"))),
                      hr(),
                      
                      #### Output: Final Result                    ####
                      h3("Final Result"),
                      hr(),
                      
                      tabsetPanel(
                        tabPanel("Gene List, estimated coefficients and p-values", 
                                 # h4("Gene List"),
                                 # verbatimTextOutput("cox.gene.cv.result.genelist"),
                                 
                                 h4("Estimated coefficients and p-values"),
                                 verbatimTextOutput("cox.gene.cv.result.coefandp")
                        ),
                        
                        tabPanel("Prediction Power", 
                                 h4("C-index"),
                                 helpText("Concordance index. C-index it measures how well the model discriminates between different responses, i.e., is your predicted response low for low observed responses and high for high observed responses."),
                                 verbatimTextOutput("cox.gene.cv.result.cindex")
                        )
                      )
                        
                      
                      
             ),
             #### table5: Tutorial (screen shot) ####
             tabPanel("Tutorial for HDMAC (web application)",
                      textOutput('text5_1'),
                      h3(textOutput('text5_2')),
                      textOutput('text5_3'),
                      imageOutput("image1"),
                      textOutput('text5_4'),
                      imageOutput("image2", height = 500),
                      imageOutput("image3"),
                      h3(textOutput('text5_5')),
                      textOutput('text5_6'),
                      textOutput('text5_7'),
                      textOutput('text5_8'),
                      imageOutput("image4", height = 700),
                      textOutput('text5_9'),
                      imageOutput("image5"),
                      textOutput('text5_10'),
                      imageOutput("image6"),
                      textOutput('text5_11'),
                      imageOutput("image7"),
                      textOutput('text5_12'),
                      imageOutput("image8"),
                      h3(textOutput('text5_13')),
                      textOutput('text5_14'),
                      textOutput('text5_15'),
                      imageOutput("image9"),
                      textOutput('text5_16'),
                      imageOutput("image10"),
                      textOutput('text5_17'),
                      imageOutput("image11"),
                      textOutput('text5_18'),
                      imageOutput("image12"),
                      textOutput('text5_19'),
                      imageOutput("image13")
                      )
             
             
  )
)

